MedQB v1.1 更新手順（既存GitHubリポジトリ用）

更新内容
・画像問題50問追加（総問題数1,879問）
・Androidの時刻とMedQBタイトルが重なる問題を修正
・versionCode 2 / versionName 1.1

GitHubで行うこと
1. このZIPを解凍する
2. MedQB- リポジトリを開く
3. Codeタブ → Add file → Upload files
   ※Add fileが無ければ、ファイル一覧上部のアップロード導線を使う
4. 解凍した以下3ファイルを同時にアップロードする
   - index.html
   - MainActivity.java
   - build.gradle
5. 同名ファイルの変更として表示されることを確認
6. Commit changes を押す
7. Actions → Build MedQB APK を開く
8. 緑のチェックになるまで待つ
9. Artifacts → MedQB-APK をダウンロード
10. ZIP内の app-debug.apk をAndroidで開く

重要
現在のAPKはGitHub Actionsのdebug署名なので、新しいAPKが旧アプリへ
そのまま上書きできない場合があります。

更新前に現在のMedQBで「学習データ書き出し」を行ってください。
上書きできなければ、
旧MedQBをアンインストール → 新APKをインストール → 学習データ読み込み
で復元できます。

今後は固定署名を設定すれば、v1.2以降を通常のアプリ更新のように
上書きインストールできるようにできます。
